---
name: Dahinchu Agni App
description: Key decisions and real data for the Dahinchu Agni Ministries mobile Expo app
---

# Dahinchu Agni Ministries App

## Real Ministry Data
- YouTube Channel ID: `UChxz3kSq1sw0pLD3Pg-Vj7w` (handle: `Dahinchuagni`)
- Website: `https://dahinchuagni.org`
- Address: Thummalova, Gokavaram Bus Stand Back Side, Rajahmundry, Andhra Pradesh 533103, India
- Phone: +91 88334 44009 · Email: dahinchuagni@gmail.com
- Founded: 1994 · Founder: Dr. Thomas (born July 11, 1970, Madurai, Tamil Nadu)
- 530+ churches, 1,800+ pastors, 17 ministries, School of Dunamis bible school

## Admin Passcode
- Passcode: `DAFIRE94` (defined as `ADMIN_PASSCODE` in `constants/ministry.ts`)
- Admin UI uses text input (not numpad) since passcode contains letters
- Access admin panel by long-pressing version text for 3 seconds in More tab (if not admin)

## YouTube CORS
- YouTube RSS is CORS-blocked on web browsers
- **Fix**: API server (`artifacts/api-server`) proxies at `GET /api/youtube/feed?channelId=...`
- Mobile hook detects `Platform.OS === "web"` and uses proxy URL; native uses direct RSS

## Banner Design
- Light orange gradient blending into white app background
- Colors: `["#F97316", "#FB923C", "#FED7AA", "#FFF7ED", colors.background]`
- Text in dark earthy tones: `#431407` (name), `#9A3412` (tagline)
- Logo tries to load from `https://dahinchuagni.org/images/logo.png` with animated flame fallback
